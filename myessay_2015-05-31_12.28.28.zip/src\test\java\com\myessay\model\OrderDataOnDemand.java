package com.myessay.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Order.class)
public class OrderDataOnDemand {
}
