package com.myessay.model;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Subject.class)
public class SubjectIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
