package com.myessay.model;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Order.class)
public class OrderIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
