package com.myessay.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Uploadfile.class)
public class UploadfileDataOnDemand {
}
