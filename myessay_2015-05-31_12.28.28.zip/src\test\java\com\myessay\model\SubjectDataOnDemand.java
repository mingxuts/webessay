package com.myessay.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Subject.class)
public class SubjectDataOnDemand {
}
