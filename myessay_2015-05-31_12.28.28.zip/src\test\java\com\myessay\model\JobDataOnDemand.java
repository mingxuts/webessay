package com.myessay.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Job.class)
public class JobDataOnDemand {
}
