package com.myessay.model;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Userinfo.class)
public class UserinfoDataOnDemand {
}
