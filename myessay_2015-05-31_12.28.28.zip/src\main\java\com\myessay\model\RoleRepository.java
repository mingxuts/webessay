package com.myessay.model;
import org.springframework.roo.addon.layers.repository.jpa.RooJpaRepository;

@RooJpaRepository(domainType = Role.class)
public interface RoleRepository {
}
