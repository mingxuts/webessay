package com.myessay.model;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Message.class)
public class MessageIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
